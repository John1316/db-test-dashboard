import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loader-action',
  templateUrl: './loader-action.component.html',
  styleUrls: ['./loader-action.component.scss']
})
export class LoaderActionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
